﻿$(document).ready(function()
  {
    $(".Registration").active(function() 
       {
          $(".Auterification").stop().animate({ backgroundColor: "#FF4500"}, 400);
       }

  });
