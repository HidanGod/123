﻿function changeVideo(id) {

	   document.getElementById('video').innerHTML = '<iframe width="425" height="349" src="http://www.youtube.com/embed/'+id+
	   '" frameborder="0" allowfullscreen class="frame"></iframe>';

	}