﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;


namespace weRid

{
	public  class jsonobjkt
	{
		public List<string> urlcaptcha { get; set; }
		public List<string> zaglav { get; set; }
		public List<string> idposta { get; set; }
		public List<string> avtoravatar { get; set; }
		public List<string> textkratk { get; set; }
		public List<string> avtorname { get; set; }
		public List<string> idavtor { get; set; }
		public List<string> reitpost { get; set; }
		public List<string> prosmotrov { get; set; }
		public List<string> tip { get; set; }
		//public int lenta { get; set; }
	}
}

