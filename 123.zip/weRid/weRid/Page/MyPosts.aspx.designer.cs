﻿using System;
using System.Web;
using System.Web.UI;

namespace weRid
{
	
	public partial class MyPosts
	{
		protected System.Web.UI.HtmlControls.HtmlForm form;

		protected System.Web.UI.WebControls.Panel Paneltopmenu;

		protected System.Web.UI.WebControls.ImageButton poisk;

		protected System.Web.UI.WebControls.ImageButton avatar;

		protected System.Web.UI.WebControls.TextBox TextBoxPoisk;

		protected System.Web.UI.WebControls.LinkButton name;

		protected System.Web.UI.WebControls.ImageButton logo;

		protected System.Web.UI.WebControls.ImageButton exit;

		protected System.Web.UI.WebControls.Panel topPanelbutton;

		protected System.Web.UI.WebControls.Button tekuchie;

		protected System.Web.UI.WebControls.Button popula;

		protected System.Web.UI.WebControls.Panel Panelmenu;

		protected System.Web.UI.WebControls.Button glbutton;

		protected System.Web.UI.WebControls.Button mypage;

		protected System.Web.UI.WebControls.Button takebutton;

		protected System.Web.UI.WebControls.Button givebutton;

		protected System.Web.UI.WebControls.TextBox TextBoxPoisk1;

		protected System.Web.UI.WebControls.Panel MainPanel;

		protected System.Web.UI.WebControls.Table Table1;

		protected System.Web.UI.WebControls.Label hiden;

		protected System.Web.UI.WebControls.Panel botPanelbutton;

		protected System.Web.UI.WebControls.ImageButton logo1;

		protected System.Web.UI.WebControls.ImageButton info;

		protected System.Web.UI.UpdatePanel UpdatePanel1;

		protected System.Web.UI.WebControls.Login Login1;

		protected System.Web.UI.WebControls.Button PostCreat;

	}
}

